ALTER TABLE notify_notifications ADD COLUMN expires_at INTEGER;
