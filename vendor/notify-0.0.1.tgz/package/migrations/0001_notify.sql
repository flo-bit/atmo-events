-- @atmo-dev/notify schema. Timestamps are unix milliseconds.
-- Keep these tables in stable storage, not in a rebuildable index database.

CREATE TABLE IF NOT EXISTS notify_notifications (
  id TEXT PRIMARY KEY,
  recipient TEXT NOT NULL,
  category TEXT NOT NULL,
  -- Deterministic per-recipient identity; sending the same key twice is a no-op.
  key TEXT NOT NULL,
  title TEXT NOT NULL,
  body TEXT,
  uri TEXT,
  -- The record this notification is about (usually an at:// URI).
  subject TEXT,
  actors TEXT,
  created_at INTEGER NOT NULL,
  -- When it becomes visible in the postbox and due for delivery.
  send_at INTEGER NOT NULL,
  read_at INTEGER,
  dispatched_at INTEGER,
  UNIQUE (recipient, key)
);
CREATE INDEX IF NOT EXISTS notify_notifications_inbox
  ON notify_notifications (recipient, send_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS notify_notifications_due
  ON notify_notifications (send_at) WHERE dispatched_at IS NULL;

-- A place a notification can be delivered, e.g. one browser's push subscription.
CREATE TABLE IF NOT EXISTS notify_targets (
  id TEXT PRIMARY KEY,
  did TEXT NOT NULL,
  channel TEXT NOT NULL,
  ref TEXT NOT NULL,
  label TEXT,
  config TEXT NOT NULL DEFAULT '{}',
  created_at INTEGER NOT NULL,
  UNIQUE (channel, ref)
);
CREATE INDEX IF NOT EXISTS notify_targets_did ON notify_targets (did);

-- Outbox: one row per (notification, target). status: pending | sent | failed | gone | skipped.
CREATE TABLE IF NOT EXISTS notify_deliveries (
  notification_id TEXT NOT NULL,
  target_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at INTEGER NOT NULL,
  claim TEXT,
  claimed_until INTEGER,
  error TEXT,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (notification_id, target_id)
);
CREATE INDEX IF NOT EXISTS notify_deliveries_due
  ON notify_deliveries (next_attempt_at) WHERE status = 'pending';
CREATE INDEX IF NOT EXISTS notify_deliveries_claim ON notify_deliveries (claim);

-- Per-user channel overrides; a missing row means the category default.
CREATE TABLE IF NOT EXISTS notify_preferences (
  did TEXT NOT NULL,
  category TEXT NOT NULL,
  channels TEXT NOT NULL,
  PRIMARY KEY (did, category)
);

-- People who use the app; see the `audience` option.
CREATE TABLE IF NOT EXISTS notify_users (
  did TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL
);

-- Small key/value store for change detection (see Notify.track).
CREATE TABLE IF NOT EXISTS notify_state (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
