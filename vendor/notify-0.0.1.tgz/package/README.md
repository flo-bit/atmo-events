# @atmo-dev/notify

Notifications for one app: a postbox, per-category preferences and web push, stored in your own
database and delivered from your own Worker.

- **Postbox.** Every notification is stored and listed, whether or not anything is pushed.
- **Preferences.** You declare categories; each user chooses per category: off, postbox only,
  or postbox plus channels such as push.
- **Delivery queue.** Retries with backoff, scheduled sends, and cleanup of dead subscriptions.
- **Web push.** VAPID and payload encryption on WebCrypto, no Node dependencies.
- **Contrail adapter.** Turn indexed record changes into notifications.

Runs on Cloudflare Workers with D1. Any database offering the small `SqlDatabase` interface
works; a `node:sqlite` adapter is included.

## Setup

```sh
pnpm add @atmo-dev/notify
pnpm exec notify-vapid   # prints VAPID_PUBLIC_KEY, VAPID_PRIVATE_JWK, VAPID_SUBJECT
```

Apply the SQL files in `node_modules/@atmo-dev/notify/migrations/` in order, or call
`notify.setup()` to create or upgrade the schema. Use one of these approaches, not both. Use a database you never rebuild: subscriptions, preferences and the
postbox are authoritative data, unlike an index.

```ts
import { createNotify, webPush } from '@atmo-dev/notify';

const notify = createNotify({
	db: env.DB,
	categories: {
		reminder: { title: 'Event reminders', channels: ['push'] },
		invite: { title: 'Invites', channels: ['push'] },
		rsvp: { title: 'New RSVPs' } // postbox only unless the user opts in
	},
	channels: {
		push: webPush({
			publicKey: env.VAPID_PUBLIC_KEY,
			privateJwk: env.VAPID_PRIVATE_JWK,
			subject: env.VAPID_SUBJECT
		})
	}
});
```

## Sending

```ts
await notify.send({
	recipient: 'did:plc:…',
	category: 'invite',
	title: 'Mira invited you',
	body: 'Atmosphere meetup, Vienna',
	uri: '/p/mira.example/e/3kabc',          // http(s) URL or same-site path
	subject: 'at://did:plc:…/…/3kabc',       // the record this is about
	actors: [{ did: 'did:plc:…', handle: 'mira.example' }],
	key: 'invite:at://did:plc:…/…/3kabc'     // same key twice = sent once
});

ctx.waitUntil(notify.deliver());
```

- `key` makes sending idempotent per recipient. Derive it from the source record so retries,
  replays and a second app deriving the same notification all agree on its identity.
- `sendAt` holds a notification back: it stays out of the postbox and is not pushed until due.
  `notify.cancel(recipient, key)` withdraws it.
- `expiresAt` stops external delivery at a deadline without removing the postbox item.
  For event reminders, use the event's start time. Web push caps provider TTL at the time left.
- `sendMany([...])` records a fan-out in batches.
- With `audience: 'enrolled'`, only people who have used the app are notified. The HTTP handler
  enrolls every signed-in user who opens their postbox; call `notify.enroll(did)` to do it
  yourself. Use this when recipients come from the wider network, such as hosts of events
  created in other apps.

## Delivering

`send` only writes. `notify.deliver()` fans due notifications out to the recipient's targets and
attempts pending deliveries. Call it after sending and from a cron trigger; overlapping runs are
safe. The limit applies to attempts against external targets, not postbox-only items.
Time-sensitive deliveries are attempted in deadline order before those without a deadline.

```ts
async scheduled(_event, env, ctx) {
	ctx.waitUntil(notify.deliver());                             // retries and scheduled sends
	ctx.waitUntil(notify.prune(Date.now() - 90 * 86_400_000));   // optional retention
}
```

A failed delivery is retried after 1 min, 5 min, 30 min and 2 h, then marked failed
(`maxAttempts`, default 5). A subscription the push service reports as expired is removed. A
notification that is already read, or more than `maxDelay` (default 24 h) late, is not pushed.

## HTTP API and browser client

Mount the handler on a catch-all route and pass the DID from your own session:

```ts
// src/routes/api/notify/[...path]/+server.ts
import { createNotifyHandler } from '@atmo-dev/notify/handler';

const handle = createNotifyHandler(notify, { vapidPublicKey: env.VAPID_PUBLIC_KEY });
export const fallback = ({ request, locals }) => handle(request, locals.did);
```

It serves the signed-in user's postbox, read state, preferences and push subscriptions. Writes
must be same-origin JSON. Push subscriptions are only accepted for known browser push services.
Responses are `private, no-store`.

```ts
import { createNotifyClient } from '@atmo-dev/notify/client';

const client = createNotifyClient();
const { items, cursor, unread } = await client.inbox();
await client.unread();                 // count only, no enrollment write
await client.markRead([items[0].id]);   // or markRead() for all
await client.setPreference('rsvp', ['push']);   // [] = postbox only, 'off' = nothing, null = default

await client.push.enable();    // from a click handler; asks for permission
await client.push.sync();      // on load: ties this browser to the signed-in account
await client.push.disable();
```

In the service worker:

```ts
import { handlePush } from '@atmo-dev/notify/sw';

handlePush(self, { icon: '/icon-192.png' });
```

Sign-out should call `client.push.disable()`, otherwise the browser keeps receiving the previous
account's notifications until someone else signs in.

## From Contrail

Register an [outbox](https://github.com/flo-bit/contrail) consumer and map record changes to
notifications:

```ts
import { notifyDelivery } from '@atmo-dev/notify/contrail';

createWorker(config, {
	deliveries: {
		notify: notifyDelivery(notify, {
			'community.lexicon.calendar.rsvp': async ({ uri, did, value }) => {
				if (!value) return;
				const host = await findHost(value);
				return [{ recipient: host, category: 'rsvp', title: '…', key: `rsvp:${uri}` }];
			}
		})
	}
});
```

Contrail delivers at least once and coalesces repeated changes into the latest record, so:

- always set `key`;
- to notify about an *edit*, compare against what you last saw:

```ts
const fingerprint = JSON.stringify([event.startsAt, event.location, event.status]);
const previous = await notify.track(`event:${uri}`, fingerprint);
if (previous !== null && previous !== fingerprint) {
	// include the fingerprint in the key so each distinct change notifies once
}
```

`notify.track(key, value, { ifNew: true })` records a baseline without overwriting one, and
`notify.peek(key)` reads it. The same store works for polling cursors.

## Adding a channel

A channel is one function. Throw to retry, return `'gone'` to drop the target.

```ts
const email: Channel = {
	async send(target, notification) {
		const response = await sendMail(target.ref, notification);
		return response.ok ? 'sent' : Promise.reject(new Error(`mail ${response.status}`));
	}
};
```

Register targets with `notify.addTarget(did, { channel: 'email', ref: address })`.

## Not included

- Email, Telegram and other channels (the interface is there, no implementations yet).
- Grouping or digesting notifications.
- UI. `apps/example` has a postbox, a push toggle and preferences built with Atmo Kit.
